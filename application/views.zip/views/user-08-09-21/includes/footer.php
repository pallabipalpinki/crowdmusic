      </main>
      <footer id="footer">
         <div class="container-fluid text-center text-md-left">
            <div class="row">
               <div class="col-auto mx-auto">
                  <a href="#" class="logo"><img src="<?php echo base_url(); ?>assets/images/logo.png" alt=""></a>
               </div>
            </div>
            <div class="bottom-nav m_top_60">
               <div class="row align-items-center">
                  <div class="col-md-auto mb-3 mb-md-0 footer-nav">
                     <ul class="list-unstyled social-links">
                        <li><a href="#">Home</a></li>
                        <li><a href="#">About Us</a></li>
                        <li><a href="#">Privacy Policy</a></li>
                        <li><a href="#">Work with Us</a></li>
                        <li><a href="#">Contact Us</a></li>
                     </ul>
                  </div>
                  <div class="col-md-auto ml-md-auto">
                     <ul class="list-unstyled list-inline social">
                        <li class="list-inline-item">
                           <a href="#"><img src="<?php echo base_url(); ?>assets/images/facebook.png" /></a>
                        </li>
                        <li class="list-inline-item">
                           <a href="#"><img src="<?php echo base_url(); ?>assets/images/twitter.png" /></a>
                        </li>
                        <li class="list-inline-item">
                           <a href="#"><img src="<?php echo base_url(); ?>assets/images/linkedin.png" /></a>
                        </li>
                     </ul>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-2 text-center text-white">
                  <p class="copyright">Copyright © 2021.<a class="text-green ml-2" href="#" target="_blank">Crowdmusiq.com</a> </p>
               </div>
               <hr>
            </div>
         </div>
      </footer>
<script type="text/javascript">
  
  var base_url= '<?php echo base_url();?>';
</script>

      <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> -->
      <script
  src="https://code.jquery.com/jquery-3.6.0.min.js"
  integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
  crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous"></script>
      <script src="<?php echo base_url(); ?>assets/js/jquery.flipster.min.js"></script>
      <script src="<?php echo base_url(); ?>assets/js/gsap.min.js"></script>
      <script src="//cdnjs.cloudflare.com/ajax/libs/ScrollMagic/2.0.7/ScrollMagic.min.js"></script>
      <script src="//cdnjs.cloudflare.com/ajax/libs/ScrollMagic/2.0.7/plugins/debug.addIndicators.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
      <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"></script>
      <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/additional-methods.min.js"></script>
      <script src="<?php echo base_url(); ?>assets/js/howler/howler.core.js"></script>
      <script src="<?php echo base_url(); ?>assets/js/siriwave.js"></script>
      <script src="<?php echo base_url(); ?>assets/js/jQuery.tagify.min.js"></script>
      <script src="<?php echo base_url(); ?>assets/js/custom.js"></script>

      <script src="<?php echo base_url(); ?>assets/js/audio7_html5/js/jquery.mousewheel.min.js?ver=4.9.18"></script>
      <script src="<?php echo base_url(); ?>assets/js/audio7_html5/js/jquery.touchSwipe.min.js?ver=4.9.18"></script>
      <script src="<?php echo base_url(); ?>assets/js/audio7_html5/js/jquery.touchSwipe.min.js?ver=4.9.18"></script>
      <script src="<?php echo base_url(); ?>assets/js/audio7_html5/js/audio7_html5.js?ver=4.9.18"></script>

      <!-- <script type='text/javascript' src="https://stickyfullwidth.audioplayerhtml5.com/wp-content/plugins/lbg-audio7_html5_full_width_sticky_pro/audio7_html5/js/jquery.mousewheel.min.js?ver=4.9.18"></script>
<script type='text/javascript' src="https://stickyfullwidth.audioplayerhtml5.com/wp-content/plugins/lbg-audio7_html5_full_width_sticky_pro/audio7_html5/js/jquery.touchSwipe.min.js?ver=4.9.18"></script>
<script type='text/javascript' src="https://stickyfullwidth.audioplayerhtml5.com/wp-content/plugins/lbg-audio7_html5_full_width_sticky_pro/audio7_html5/js/audio7_html5.js?ver=4.9.18"></script> -->

   

   <!-- <script type='text/javascript' src="https://stickyfullwidth.audioplayerhtml5.com/wp-includes/js/jquery/ui/core.min.js?ver=1.11.4"></script> -->
<script type='text/javascript' src="<?php echo base_url(); ?>assets/js/audio7_html5/js/widget.min.js?ver=1.11.4"></script>
<script type='text/javascript' src="<?php echo base_url(); ?>assets/js/audio7_html5/js/mouse.min.js?ver=1.11.4"></script>
<script type='text/javascript' src="<?php echo base_url(); ?>assets/js/audio7_html5/js/slider.min.js?ver=1.11.4"></script>
<script type='text/javascript' src="<?php echo base_url(); ?>assets/js/audio7_html5/js/progressbar.min.js?ver=1.11.4"></script>
<script type='text/javascript' src="<?php echo base_url(); ?>assets/js/audio7_html5/js/effect.min.js?ver=1.11.4"></script>
<!-- <script type='text/javascript' src="https://stickyfullwidth.audioplayerhtml5.com/wp-content/themes/hashone/js/jquery.bxslider.js?ver=4.1.2"></script>
<script type='text/javascript' src="https://stickyfullwidth.audioplayerhtml5.com/wp-content/themes/hashone/js/owl.carousel.js?ver=1.3.3"></script> -->
<script type='text/javascript' src="https://stickyfullwidth.audioplayerhtml5.com/wp-includes/js/imagesloaded.min.js?ver=3.2.0"></script>
<script type='text/javascript' src="https://stickyfullwidth.audioplayerhtml5.com/wp-content/themes/hashone/js/isotope.pkgd.js?ver=20150903"></script>
<script type='text/javascript' src="https://stickyfullwidth.audioplayerhtml5.com/wp-content/themes/hashone/js/nivo-lightbox.js?ver=20150903"></script>
<script type='text/javascript' src="https://stickyfullwidth.audioplayerhtml5.com/wp-content/themes/hashone/js/jquery.stellar.js?ver=20150903"></script>
<script type='text/javascript' src="https://stickyfullwidth.audioplayerhtml5.com/wp-content/themes/hashone/js/wow.js?ver=20150903"></script>
<script type='text/javascript' src="https://stickyfullwidth.audioplayerhtml5.com/wp-content/themes/hashone/js/odometer.js?ver=20150903"></script>
<script type='text/javascript' src="https://stickyfullwidth.audioplayerhtml5.com/wp-content/themes/hashone/js/waypoint.js?ver=20150903"></script>
<!-- <script type='text/javascript' src="https://stickyfullwidth.audioplayerhtml5.com/wp-content/themes/hashone/js/jquery.nav.js?ver=20161003"></script> -->
<!-- <script type='text/javascript' src="https://stickyfullwidth.audioplayerhtml5.com/wp-content/themes/hashone/js/SmoothScroll.js?ver=20150903"></script>
<script type='text/javascript' src="https://stickyfullwidth.audioplayerhtml5.com/wp-content/themes/hashone/js/hashone-custom.js?ver=20150903"></script> -->

      <?php
      if($this->session->userdata('SESSION_USER_ID')){
         ?>
         <script src="<?php echo base_url(); ?>assets/js/account_edit.js"></script>        
         <script src="<?php echo base_url(); ?>assets/js/contents.js"></script>
         <?php
      }else{
         ?>
         <script src="<?php echo base_url(); ?>assets/js/account.js"></script>
         <?php
      }
      
      ?>

      <script>
      jQuery(function() {
         jQuery("#lbg_audio7_html5_7").audio7_html5({
            skin:"blackControllers",
            initialVolume:0.6,
            autoPlay:true,
            loop:true,
            shuffle:false,
            sticky:true,
            playerBg:"#c1956e",
            bufferEmptyColor:"#929292",
            bufferFullColor:"#6a1a0c",
            seekbarColor:"#FFFFFF",
            volumeOffColor:"#6a1a0c",
            volumeOnColor:"#FFFFFF",
            timerColor:"#333333",
            songTitleColor:"#555555",
            songAuthorColor:"#333333",
            googleTrakingOn:false,
            googleTrakingCode:"",
            showVinylRecord:false,
            showRewindBut:true,
            showNextPrevBut:true,
            showShuffleBut:true,
            showDownloadBut:false,
            showBuyBut:false,
            showLyricsBut:false,
            buyButTitle:"Buy Now",
            lyricsButTitle:"Lyrics",
            buyButTarget:"_blank",
            lyricsButTarget:"_blank",
            showFacebookBut:false,
            facebookAppID:"421717828200528",
            facebookShareTitle:"Apollo - HTML5 Audio Player",
            facebookShareDescription:"A top-notch sticky full width HTML5 Audio Player compatible with all major browsers and mobile devices.",
            showTwitterBut:false,
            showPopupBut:false,
            showAuthor:true,
            showTitle:true,
            showPlaylistBut:true,
            showPlaylist:true,
            showPlaylistOnInit:false,
            playlistTopPos:0,
            playlistBgColor:"#c1956e",
            playlistRecordBgOffColor:"#6a1a0c",
            playlistRecordBgOnColor:"#000000",
            playlistRecordBottomBorderOffColor:"#c1956e",
            playlistRecordBottomBorderOnColor:"#c1956e",
            playlistRecordTextOffColor:"#cccccc",
            playlistRecordTextOnColor:"#ffffff",
            categoryRecordBgOffColor:"#191919",
            categoryRecordBgOnColor:"#f12233",
            categoryRecordBottomBorderOffColor:"#2f2f2f",
            categoryRecordBottomBorderOnColor:"#2f2f2f",
            categoryRecordTextOffColor:"#4c4c4c",
            categoryRecordTextOnColor:"#ffffff",
            numberOfThumbsPerScreen:5,
            playlistPadding:15,
            showCategories:true,
            firstCateg:"",
            selectedCategBg:"#dedede",
            selectedCategOffColor:"#333333",
            selectedCategOnColor:"#f12233",
            selectedCategMarginBottom:12,
            showSearchArea:true,
            searchAreaBg:"#dedede",
            searchInputText:"search...",
            searchInputBg:"#000000",
            searchInputBorderColor:"#dedede",
            searchInputTextColor:"#cccccc",
            searchAuthor:true,
            continuouslyPlayOnAllPages:true,
            showPlaylistNumber:true,
            pathToDownloadFile:"http://stickyfullwidth.audioplayerhtml5.com/wp-content/plugins/lbg-audio7_html5_full_width_sticky_pro/audio7_html5/",
            popupWidth:1100,
            popupHeight:500,
            barsColor:"#ffffff",
            isSliderInitialized:false,
            isProgressInitialized:false
         });
      });
   </script>

      <script type="text/javascript">
        function openSignin(){
          $('#signinModalId').modal('show');
          $('#signupModalId').modal('hide');
        }

         // var controller = new ScrollMagic.Controller();

         // new ScrollMagic.Scene({
         //    duration: 400,
         //    offset: $('#equipmentImg').offset().top + $('#equipmentImg').height() - $(window).height()
         // })
         // .setPin('#equipmentImg')
         // .addIndicators({name: "1 (duration: 0)"})
         // .addTo(controller);


      $(".likebtn").click(function() {
      var d=$(this).attr('data-thumbs');
      var track_id=$(this).attr('data-track');
      var artist_id=$(this).attr('data-artist');
      //alert(track_id);
      $('#idown').removeClass('fas fa-thumbs-down');
      $('#iup').removeClass('fas fa-thumbs-down');
      if(d=='down'){
         $('#idown').addClass('fas fa-thumbs-down');
         $('#iup').addClass('far fa-thumbs-up');
      }else if(d=='up'){
         $('#idown').addClass('far fa-thumbs-down');
         $('#iup').addClass('fas fa-thumbs-down');
      }


            
          $.ajax({
         type:'POST',
         data:{d:d,track_id:track_id,artist_id:artist_id},
          url:base_url+'user-addlike',
           success:function(data){
          //   if (data.st == 0) {
          //   $('#likedata').html(data.msg);
          // } else
          //  if (data.st == 1) {
            
          // }
        }
      },
        'json');
      return false;
  
   });











      </script>
   </body>
</html>