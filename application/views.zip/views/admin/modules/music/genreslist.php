<section class="content"> -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">GENRES</h1>
          </div><!-- /.col -->
         <!--  <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?= base_url('admin/logout')?>">Logout</a></li>
              <li class="breadcrumb-item active">Dashboard v2</li>
            </ol>
          </div> /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
<div class="container-fluid">

        <!-- <div class="row"> -->
          <!-- <div class="col-md-6"> -->
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">GENRES LIST</h3>
                  <?php
                  if($this->session->userdata('success')){?>
                  <br><span style="color:green;"><?= $this->session->userdata('success')?></span> <?php 
                  $this->session->unset_userdata('success'); }
                   ?> 
                  <?php if($this->session->userdata('fail')){?>
                  <br><span style="color:green;"><?= $this->session->userdata('fail')?></span> <?php 
                  $this->session->unset_userdata('fail'); } 
                  ?> 
                <div class="add-button" style="float: right;width: 6%;">
                <a class="btn btn-block btn-primary" href="<?= base_url('admin/genres-add') ?>" style="padding:5px"><i class="fa fa-user-plus" aria-hidden="true" ></i>ADD</a>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body">

                <table id="genresid" class="table table-bordered table-striped">
                  <thead>                  
                    <tr>
                      <th style="width: 10px">SL.</th>
                      <th>Name</th>
                      <!-- <th>ABOUT</th> -->
                      <th style="width: 200px">ACTION</th>
                    </tr>
                  </thead>
                  <tbody>
                     <?php
                       $i=1;
                        if($list)
                        { 
                            foreach($list as $genres)
                            {?>

                  	 <tr id="genres_<?= $genres["genere_id"]?>">
                      <td><?= $i ?></td>
                      <td><?= $genres["genere_name"]?></td>
                     <!--  <td><?= $genres["about"]?></td> -->
                     
                      <td>
                      <a class="btn btn-warning btn-sm" href="<?=base_url('admin/genres-edit/'.$genres['genere_id'])?>" title="Edit"><i class="fas fa-pencil-alt"> </i>Edit</a>
                     
                      <?php if($genres['genere_status'] == 1){ ?>

                     <a class="btn btn-success btn-sm" href="javascript:void(0);" onclick="mygenresStatus('<?=base_url('admin/genres-status/'.$genres['genere_id'])?>','<?= $genres['genere_id']?>','<?= $genres['genere_status']?>')" title="make inactive"></i>active</a>
                             
                    <?php }else{ ?>

                  <a class="btn btn-danger btn-sm" href="javascript:void(0);" onclick="mygenresStatus('<?=base_url('admin/genres-status/'.$genres['genere_id'])?>','<?= $genres['genere_id']?>','<?= $genres['genere_status']?>')" title="make active">inactive</a>

                    <?php } ?>




                    <!--  <a class="btn btn-danger btn-sm" href="javascript:;" title="delete" onclick="mygenresDelete('<?=base_url('admin/genres-delete/'.$genres['genere_id'])?>','<?= $genres['genere_id']?>')"><i class="fas fa-trash"> </i> Delete</a> -->
                      
                    

                      </td>
                    </tr>
                    <?php $i++;} } ?>
                  </tbody>
                </table>
              </div>

               <div class="card-footer clearfix">
             <!--  <?php if($pagination_link) {
               $pagination_link->setPath('Ci_Music/index.php/admin/userlist');?>
               <ul class="pagination pagination-sm m-0 float-right">
                <li class="page-item"><?= $pagination_link->links()?></li>
                    <?php
                     // $pagination_link->links(); 
                  } ?> 
                  </ul>-->
                    </div>
              <!-- /.card-body -->
             <!--  <div class="card-footer clearfix">
                <ul class="pagination pagination-sm m-0 float-right">
                  <li class="page-item"><a class="page-link" href="#">«</a></li>
                  <li class="page-item"><a class="page-link" href="#">1</a></li>
                  <li class="page-item"><a class="page-link" href="#">2</a></li>
                  <li class="page-item"><a class="page-link" href="#">3</a></li>
                  <li class="page-item"><a class="page-link" href="#">»</a></li>
                </ul>
              </div>
            </div> -->
          
            
          <!-- </div> -->
         </div> 
    </div>
  </div>


<!-- </section>