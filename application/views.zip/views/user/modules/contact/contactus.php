<main id="page-view">
		<section class="inner-pg">
			<div class="inner-cover-div">
				<a class="inner-cover-bg twPc-block"> <img src="images/innercover.jpg" /> </a>
				<div class="about-section">
					<div class="container">
						<div class="row">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 ">
								<div class="header-title onview viewed">

									<!-- <p class="sub">Lorem Ipsum</p> -->
									<h2>Contact Us</h2>
									<p>A wonderful designs has takenpossession but also the leap into electronic pesetting industry  It was popularised in the 1960s with the release </p>
								 </div>
							</div>
						</div>
						<div class="row">
								<div class="col-sm-6">
								<iframe width="100%" height="320px;" frameborder="0" style="border:0" src="https://www.google.com/maps/embed/v1/place?q=place_id:ChIJaY32Qm3KWTkRuOnKfoIVZws&key=AIzaSyAf64FepFyUGZd3WFWhZzisswVx2K37RFY" allowfullscreen></iframe>
								</div>
						
								<div class="col-sm-6">
									<form action="form.php" class="contact-form" method="post">
							
										<div class="form-group">
										  <input type="text" class="form-control" id="name" name="nm" placeholder="Name" required="" autofocus="">
										</div>
									
									
										<div class="form-group form_left">
										  <input type="email" class="form-control" id="email" name="em" placeholder="Email" required="">
										</div>
									
									  <div class="form-group">
										   <input type="text" class="form-control" id="phone" onkeypress="return event.charCode >= 48 && event.charCode <= 57" maxlength="10" placeholder="Mobile No." required="">
									  </div>
									  <div class="form-group">
									  <textarea class="form-control textarea-contact" rows="5" id="comment" name="FB" placeholder="Type Your Message/Feedback here..." required=""></textarea>
									  <br>
										<button class="btn btn-default btn-send contact-btn"> <span class="glyphicon glyphicon-send"></span> Send </button>
									  </div>
									 </form>
								</div>
						  </div>
						
						  <div class="container second-portion">
							<div class="row">
								<!-- Boxes de Acoes -->
								<div class="col-xs-12 col-sm-6 col-lg-4">
									<div class="contact-box">							
										<div class="contact-icon">
											<div class="contact-image"><i class="fa fa-envelope" aria-hidden="true"></i></div>
											<div class="contact-info">
												<h3 class="contact-title">MAIL & WEBSITE</h3>
												<p>
													<i class="fa fa-envelope" aria-hidden="true"></i> &nbsp gondhiyahardik6610@gmail.com
													<br>
													<br>
													<i class="fa fa-globe" aria-hidden="true"></i> &nbsp www.hardikgondhiya.com
												</p>
											
											</div>
										</div>
										<div class="space"></div>
									</div> 
								</div>
									
								<div class="col-xs-12 col-sm-6 col-lg-4">
									<div class="contact-box">							
										<div class="contact-icon">
											<div class="contact-image"><i class="fa fa-mobile" aria-hidden="true"></i></div>
											<div class="contact-info">
												<h3 class="contact-title">CONTACT</h3>
												<p>
													<i class="fa fa-mobile" aria-hidden="true"></i> &nbsp (+91)-9624XXXXX
													<br>
													<br>
													<i class="fa fa-mobile" aria-hidden="true"></i> &nbsp  (+91)-756706XXXX
												</p>
											</div>
										</div>
										<div class="space"></div>
									</div> 
								</div>
									
								<div class="col-xs-12 col-sm-6 col-lg-4">
									<div class="contact-box">							
										<div class="contact-icon">
											<div class="contact-image"><i class="fa fa-map-marker" aria-hidden="true"></i></div>
											<div class="contact-info">
												<h3 class="contact-title">ADDRESS</h3>
												<p>
													 <i class="fa fa-map-marker" aria-hidden="true"></i> &nbsp 15/3 Junction Plot 
													 "Shree Krishna Krupa", Rajkot - 360001.
												</p>
											</div>
										</div>
										<div class="space"></div>
									</div> 
								</div>
							</div>
						</div>
					</div>
				</div>
				
			</div>
		</section>
	</main>