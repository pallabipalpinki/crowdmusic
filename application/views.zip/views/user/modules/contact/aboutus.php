<main id="page-view">
		<section class="inner-pg">
			<div class="inner-cover-div">
				<a class="inner-cover-bg twPc-block"> <img src="images/innercover.jpg" /> </a>
				<div class="about-section">
					<div class="container">
						<div class="row">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 ">
								<div class="header-title onview viewed">

									<!-- <p class="sub">Lorem Ipsum</p> -->
						   
									<h2>About Us</h2>
									<p>A wonderful designs has takenpossession but also the leap into electronic pesetting industry  It was popularised in the 1960s with the release </p>
								 </div>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12  about-right">
								<img src="https://images.pexels.com/photos/7096/people-woman-coffee-meeting.jpg?w=940&h=650&auto=compress&cs=tinysrgb" alt=" " />
							</div>
							<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 about-inner-column">
								<h4>Eco friendly food is good for health </h4>
								<p>Takenpossession of lorem Ipsum is simply dummy text of the printing and typesetting industry In sit amet sapien eros Integer  in tincidunt labore et dolore magna aliqua  remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages.</p>
								<ul class="about-list">
									<li><a href="#">Donec ut quam lscele volutri.</a></li>
									<li><a href="#">Etiam volutpatbh quam bortis</a></li>
									<li><a href="#">Varius fusce vit aeblandit.</a></li>
								</ul>
							</div>
						</div>
						
						<div class="about-inner-section">	
							
							<div class="clearfix"> </div>
						</div>
					</div>
				</div>
				
			</div>
		</section>
	</main>