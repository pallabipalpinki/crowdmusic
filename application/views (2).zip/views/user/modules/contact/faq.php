<main id="page-view">
		<section class="inner-pg">
			<div class="inner-cover-div">
				<a class="inner-cover-bg twPc-block"> <img src="images/innercover.jpg" /> </a>
				<div class="about-section">
					<div class="container">
						<div class="row">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 ">
								<div class="header-title onview viewed">

									<!-- <p class="sub">Lorem Ipsum</p> -->
									<h2>Faq</h2>
									<p>A wonderful designs has takenpossession but also the leap into electronic pesetting industry  It was popularised in the 1960s with the release </p>
								 </div>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-6">
								<div class="faqs">
									<!-- FAQ Item -->
								  <details class="faq_item">
									<summary class="faq_title">First Question</summary>
									<p class="faq_content">Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit...</p>
								  </details>
									<!-- END: FAQ Item -->
									
									  <!-- FAQ Item -->
								  <details class="faq_item">
									<summary class="faq_title">Second Question</summary>
									<p class="faq_content">Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit...</p>
								  </details>
									<!-- END: FAQ Item -->
									
									  <!-- FAQ Item -->
								  <details class="faq_item">
									<summary class="faq_title">Third Question</summary>
									<p class="faq_content">Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit...</p>
								  </details>
								  
								</div>
        					</div>
							<div class="col-lg-6">
								<div class="faqs">
									<!-- FAQ Item -->
								  <details class="faq_item">
									<summary class="faq_title">First Question</summary>
									<p class="faq_content">Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit...</p>
								  </details>
									<!-- END: FAQ Item -->
									
									  <!-- FAQ Item -->
								  <details class="faq_item">
									<summary class="faq_title">Second Question</summary>
									<p class="faq_content">Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit...</p>
								  </details>
									<!-- END: FAQ Item -->
									
									  <!-- FAQ Item -->
								  <details class="faq_item">
									<summary class="faq_title">Third Question</summary>
									<p class="faq_content">Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit...</p>
								  </details>
								  
								</div>
        					</div>
						</div>
						
						
					</div>
				</div>
				
			</div>
		</section>
	</main>